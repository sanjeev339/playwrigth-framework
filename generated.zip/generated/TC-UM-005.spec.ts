import { test, expect, type Locator, type Page } from '@playwright/test';

function escapeRegex(value: string): string {
  return value.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&');
}

function getLoginUrl(): string {
  const loginUrl =
    process.env.LOGIN_URL ??
    process.env.WEBSITE_URL ??
    (process.env.APP_BASE_URL
      ? `${process.env.APP_BASE_URL.replace(/\/+$/, '')}/${(process.env.LOGIN_PATH ?? 'login').replace(/^\/+/, '')}`
      : undefined);

  if (!loginUrl) {
    throw new Error('Missing LOGIN_URL, WEBSITE_URL, or APP_BASE_URL.');
  }

  return loginUrl;
}

async function firstUsable(locator: Locator): Promise<Locator | null> {
  const count = await locator.count().catch(() => 0);

  for (let index = 0; index < count; index += 1) {
    const candidate = locator.nth(index);
    const visible = await candidate.isVisible().catch(() => false);
    const enabled = await candidate.isEnabled().catch(() => false);

    if (visible && enabled) {
      return candidate;
    }
  }

  return null;
}

async function fillFirst(label: string, locators: Locator[], value: string): Promise<void> {
  for (const locator of locators) {
    const candidate = await firstUsable(locator);
    if (candidate) {
      await candidate.fill(value);
      return;
    }
  }

  throw new Error(`Unable to find input for ${label}.`);
}

async function clickFirst(label: string, locators: Locator[]): Promise<void> {
  for (const locator of locators) {
    const candidate = await firstUsable(locator);
    if (candidate) {
      await candidate.click();
      return;
    }
  }

  throw new Error(`Unable to find clickable control for ${label}.`);
}

function configuredLocator(page: Page, selector: string | undefined): Locator {
  if (!selector?.trim()) {
    return page.locator('__configured_locator_not_set__');
  }

  const trimmed = selector.trim();
  if (trimmed.startsWith('testid=')) {
    return page.getByTestId(trimmed.replace(/^testid=/, ''));
  }

  return page.locator(trimmed);
}

async function clickMenuItemAfterRowAction(label: string, openMenu: () => Locator, item: () => Locator): Promise<void> {
  let candidate = await firstUsable(item());

  if (!candidate) {
    const opener = await firstUsable(openMenu());
    if (!opener) {
      throw new Error(`Unable to find row action menu opener for ${label}.`);
    }

    await opener.click();
    candidate = await firstUsable(item());
  }

  if (!candidate) {
    throw new Error(`Unable to find row menu item for ${label}.`);
  }

  await candidate.click();
}

async function selectCustomDropdown(page: Page, openDropdown: () => Locator, optionValue: string): Promise<void> {
  await openDropdown().click();

  const exactOptionRegex = new RegExp(`^${escapeRegex(optionValue)}$`, 'i');
  const visiblePopup = page.locator('[role="listbox"], [role="menu"], [role="dialog"]').filter({ hasText: exactOptionRegex });
  const optionCandidates = [
    page.getByRole('option', { name: exactOptionRegex }),
    visiblePopup.getByRole('option', { name: exactOptionRegex }),
    visiblePopup.getByText(exactOptionRegex),
    page.locator('[aria-selected], [data-option], li[role="option"]').filter({ hasText: exactOptionRegex })
  ];

  for (const locator of optionCandidates) {
    const candidate = await firstUsable(locator);
    if (candidate) {
      await candidate.click();
      return;
    }
  }

  throw new Error(`No safe option locator found for dropdown value: ${optionValue}`);
}

test("TC-UM-005: User Management", async ({ page }) => {
  const loginEmail = process.env.LOGIN_EMAIL;
  const loginPassword = process.env.LOGIN_PASSWORD;
  const payload = {
    "First Name": "adithya",
    "Last Name": "j",
    "Full Name": "adithya j",
    "Email Address": "sanjeevkumar.m00@gmail.com",
    "Add comments": "comment",
    "Status": "Active"
  } as const;

  if (!loginEmail || !loginPassword) {
    throw new Error('Missing LOGIN_EMAIL or LOGIN_PASSWORD.');
  }

  await test.step('Login to the application', async () => {
    const loginUrl = getLoginUrl();
    await page.goto(loginUrl);

    await fillFirst('login email', [
      configuredLocator(page, process.env.LOGIN_EMAIL_SELECTOR),
      page.getByLabel(/email|username/i),
      page.getByRole('textbox', { name: /email|username/i }),
      page.getByPlaceholder(/email|username/i)
    ], loginEmail);

    await fillFirst('login password', [
      configuredLocator(page, process.env.LOGIN_PASSWORD_SELECTOR),
      page.getByLabel(/password/i),
      page.getByRole('textbox', { name: /password/i }),
      page.getByPlaceholder(/password/i)
    ], loginPassword);

    await clickFirst('login submit', [
      configuredLocator(page, process.env.LOGIN_SUBMIT_SELECTOR),
      page.getByRole('button', { name: /login|sign in|submit/i }),
      page.locator('button[type="submit"]').first()
    ]);

    await expect(page.getByRole("button", { name: /^User Management$/i })).toBeVisible({ timeout: 15000 });
  });

  await test.step("Step 1: Navigate to User Management", async () => {
    await page.getByRole("button", { name: /^User Management$/i }).click();
    await page.waitForLoadState('domcontentloaded').catch(() => undefined);
  });

  await test.step("Step 2: Enter Search By Name Or Email Id", async () => {
    await page.getByPlaceholder(/Search by name or email/i).fill(String(payload["Email Address"]));
    await expect(page.getByPlaceholder(/Search by name or email/i)).toHaveValue(String(payload["Email Address"]));
  });

  await test.step("Step 3: Click Actions Menu for sanjeevkumar.m00@gmail.com", async () => {
    await page.getByRole("row", { name: /sanjeevkumar\.m00@gmail\.com/i }).locator("button").nth(0).click();
    await page.waitForTimeout(150);
  });

  await test.step("Step 4: Click Reactivate", async () => {
    await clickMenuItemAfterRowAction("Click Reactivate", () => page.getByRole("row", { name: /sanjeevkumar\.m00@gmail\.com/i }).locator("button").nth(0), () => page.getByRole("link", { name: /^Reactivate$/i }));
    await page.waitForLoadState('domcontentloaded').catch(() => undefined);
  });

  await test.step("Step 5: Enter Add comments", async () => {
    await page.getByPlaceholder(/^Add comments$/i).fill(String(payload["Add comments"]));
    await expect(page.getByPlaceholder(/^Add comments$/i)).toHaveValue(String(payload["Add comments"]));
  });

  await test.step("Step 6: Click Reactivate", async () => {
    await page.getByRole("button", { name: /^Reactivate$/i }).click();
    await page.waitForLoadState('domcontentloaded').catch(() => undefined);
  });
});
